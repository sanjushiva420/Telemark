
var token_telemarkbot = '169717941:AAHxBBHj6YNjPvEmyjlRDCjMNhFG3JFXojY';
var unirest = require("unirest");
var stringTable = require('string-table');
var telBot = require('node-telegram-bot-api');
var bot;



if(process.env.NODE_ENV === 'production') {
  bot = new Bot(token_telemarkbot);
  bot.setWebHook('https://my-web-root.com/' + bot.token);
}
else {
 bot = new telBot(token_telemarkbot, {polling: true});
 
}
        
console.log('bot server started...');

bot.onText  (/^\/start/, function (msg, fromtg) {
     console.log('started'+fromtg[0].indexOf('start'));
     if(fromtg[0].indexOf('start')!=-1){
   bot.sendMessage(msg.chat.id, 'enter college code').then(function (msg, fromtg) {
 // reply sent!
    bot.onText(/^\d{4}/,function (msg, fromtg){
        var arg1=fromtg[0]; 
        if(arg1.length==4)
        {
        var clgCode='7145'; 
        console.log(arg1+arg1.length);
        console.log(clgCode);
        
                if(clgCode==arg1){
                     bot.sendMessage(msg.chat.id, 'enter exam type').then(function (msg, frmtg){
                      bot.onText(/^SLT(.+)$/,function (msg, frmtg){
                          var sub=frmtg[0];
                          if(sub.indexOf('SLT')!=-1){
                          console.log(sub+sub.indexOf('SLO'));
                          bot.sendMessage(msg.chat.id, 'Enter reg number').then(function( msg,fmtg){
                           bot.onText(/^\d{12}/,function (msg, fmtg){  
     console.log('startesjdakjdhakjdhd');
      var reg=fmtg[0];
          console.log(reg+reg.length);
      if(reg.length==12)
        {
    console.log(reg);
    var requrl = 'https://telemark.apispark.net/v1/' + sub + '/?Reg_No=' +reg;
       console.log('jkdhskajhdksjah');
    console.log(requrl);
    var req = unirest("GET", requrl);

    req.headers({
        "content-type": "application/json",
        "accept": "application/json",
        "host": "csemarks.apispark.net"
    });

    req.end(function (res) {
        if (res.error)
            throw new Error(res.error);
console.log(res.body);

        var totg="";
               
               totg=totg+stringTable.create(res.body,{headers:['Reg_No','Name']})+"\n\n"; 
              // totg=totg+stringTable.create(res.body,{headers:['Name']})+"\n\n";
               totg=totg+stringTable.create(res.body,{headers:['CG','MPC','DSP','WN','EEFA']})+"\n\n";
               /* totg=totg+stringTable.create(res.body,{headers:['CG']})+"\n\n";
               totg=totg+stringTable.create(res.body,{headers:['EEFA']})+"\n\n";
                totg=totg+stringTable.create(res.body,{headers:['CG']})+"\n\n";
               totg=totg+stringTable.create(res.body,{headers:['DWM']})+"\n\n";
               totg=totg+stringTable.create(res.body,{headers:['MPC']})+"\n\n";
                totg=totg+stringTable.create(res.body,{headers:['DSP']})+"\n\n";
               totg=totg+stringTable.create(res.body,{headers:['WN']})+"\n\n";*/
                  
       console.log(totg);

      bot.sendMessage(msg.chat.id, totg);
    });
      }
      else
          console.log('error');
    });
         
    });

     }
     else
         console.log('error');
    });
    });
                }
                else
                    console.log('error');
                
     }           
     else
         console.log('error');
    });
    
    

        });
        
}
});/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


